const { Telegraf } = require('telegraf');
const express = require('express');
const path = require('path');

// Load environment variables
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'web')));

// API endpoint for status
app.get('/api/status', (req, res) => {
  res.json({
    agents: [
      { name: 'SkyClaw', status: 'running', cpu: 23, lastAction: 'Posted to Moltbook', lastActive: '2m ago' },
      { name: 'ScraperBot', status: 'running', cpu: 45, lastAction: 'Scraped 142 URLs', lastActive: '5m ago' },
      { name: 'TraderAI', status: 'idle', cpu: 0, lastAction: 'Analyzed market', lastActive: '1h ago' },
      { name: 'ContentGen', status: 'error', cpu: 0, lastAction: 'Failed API call', lastActive: '12m ago' },
      { name: 'MonitorX', status: 'running', cpu: 12, lastAction: 'Health check OK', lastActive: '30s ago' },
    ],
    revenue: {
      today: 2800,
      week: 15600,
      trend: '+12%'
    },
    alerts: [
      { type: 'error', title: 'API Rate Limit Exceeded', message: 'OpenAI API hitting limits', time: '2m ago' },
      { type: 'warning', title: 'High CPU Usage', message: 'ScraperBot at 87% CPU', time: '5m ago' },
      { type: 'info', title: 'Backup Complete', message: 'Daily backup successful', time: '1h ago' },
    ],
    uptime: '15d 4h 23m',
    lastUpdate: new Date().toISOString()
  });
});

// API endpoint to control agents
app.post('/api/agent/:id/control', (req, res) => {
  const { id } = req.params;
  const { action } = req.body;
  
  console.log(`Agent ${id} action: ${action}`);
  
  setTimeout(() => {
    res.json({ success: true, message: `Agent ${id} ${action}ed successfully` });
  }, 500);
});

// Main route - serves the mini app
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'web', 'index.html'));
});

// Start web server
const server = app.listen(PORT, () => {
  console.log(`✅ Web server running on port ${PORT}`);
  console.log(`🌐 Web app available at http://localhost:${PORT}`);
});

// Start bot only if token is provided and valid
const botToken = process.env.BOT_TOKEN;
const webAppUrl = process.env.WEB_APP_URL || `http://localhost:${PORT}`;

if (botToken && botToken !== 'YOUR_BOT_TOKEN_HERE') {
  const bot = new Telegraf(botToken);

  bot.start((ctx) => {
    ctx.reply('Welcome to Mission Control! Use /menu to open the dashboard.');
  });

  bot.help((ctx) => {
    ctx.reply('Commands:\n/start - Start the bot\n/menu - Open Mission Control dashboard\n/status - Get system status');
  });

  bot.command('menu', (ctx) => {
    // Check if URL is HTTPS (required by Telegram)
    const url = webAppUrl.startsWith('https://') 
      ? webAppUrl 
      : 'https://t.me/' + (ctx.botInfo?.username || 'your_bot');
    
    ctx.reply('Open Mission Control:', {
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: '🚀 Open Dashboard',
              web_app: { url: url }
            }
          ]
        ]
      }
    }).catch(err => {
      console.error('Failed to send menu:', err.message);
      ctx.reply('⚠️ Web app URL must be HTTPS. Set WEB_APP_URL in .env to a public HTTPS URL.');
    });
  });

  bot.command('status', (ctx) => {
    ctx.reply('Fetching system status...');
    ctx.reply(`🟢 System Online\n📊 5 Agents Active\n💰 $2,800 Today\n⏱ Uptime: 15d 4h`);
  });

  bot.launch().then(() => {
    console.log('🤖 Telegram bot started');
  }).catch((err) => {
    console.error('❌ Failed to start bot:', err.message);
    console.log('   Bot will not run. Check your BOT_TOKEN in .env');
  });

  // Handle bot errors gracefully
  bot.catch((err, ctx) => {
    console.error(`Bot error for ${ctx.updateType}:`, err.message);
  });

  // Enable graceful stop
  process.once('SIGINT', () => bot.stop('SIGINT'));
  process.once('SIGTERM', () => bot.stop('SIGTERM'));
} else {
  console.log('ℹ️  No BOT_TOKEN provided. Bot features disabled.');
  console.log('   Add BOT_TOKEN to .env to enable Telegram bot integration.');
}

// Handle server errors
server.on('error', (err) => {
  console.error('Server error:', err.message);
});
