// Telegram WebApp SDK
const tg = window.Telegram.WebApp;

// Initialize
tg.expand();
tg.ready();

// State
let systemData = null;
let refreshInterval = null;

// DOM Elements
const els = {
  agentCount: document.getElementById('agentCount'),
  uptime: document.getElementById('uptime'),
  todayRevenue: document.getElementById('todayRevenue'),
  revenueTrend: document.getElementById('revenueTrend'),
  agentList: document.getElementById('agentList'),
  alertList: document.getElementById('alertList'),
  refreshBtn: document.getElementById('refreshBtn'),
  addAgentBtn: document.getElementById('addAgentBtn'),
};

// Fetch system data
async function fetchData() {
  try {
    const response = await fetch('/api/status');
    systemData = await response.json();
    updateUI();
  } catch (error) {
    console.error('Failed to fetch data:', error);
    showToast('Failed to fetch data');
  }
}

// Update all UI components
function updateUI() {
  if (!systemData) return;

  // Update status
  const activeAgents = systemData.agents.filter(a => a.status === 'running').length;
  els.agentCount.textContent = `${activeAgents}/${systemData.agents.length}`;
  els.uptime.textContent = systemData.uptime;

  // Update revenue
  els.todayRevenue.textContent = `$${systemData.revenue.today.toLocaleString()}`;
  els.revenueTrend.textContent = systemData.revenue.trend;
  els.revenueTrend.className = `revenue-change ${systemData.revenue.trend.startsWith('+') ? 'positive' : 'negative'}`;

  // Update agents
  renderAgents();

  // Update alerts
  renderAlerts();
}

// Render agent list
function renderAgents() {
  els.agentList.innerHTML = systemData.agents.map(agent => `
    <div class="agent-card" data-id="${agent.name}">
      <div class="agent-avatar">${agent.name.charAt(0)}</div>
      <div class="agent-info">
        <div class="agent-name">${agent.name}</div>
        <div class="agent-status">
          <span class="agent-status-indicator ${agent.status}"></span>
          ${agent.status} • ${agent.lastActive}
        </div>
      </div>
      <div class="agent-actions">
        ${agent.status === 'running' 
          ? `<button class="agent-btn stop" onclick="controlAgent('${agent.name}', 'stop')">⏹</button>`
          : `<button class="agent-btn start" onclick="controlAgent('${agent.name}', 'start')">▶</button>`
        }
      </div>
    </div>
  `).join('');
}

// Render alerts
function renderAlerts() {
  if (systemData.alerts.length === 0) {
    els.alertList.innerHTML = '<div class="alert-card"><div class="alert-content">No active alerts</div></div>';
    return;
  }

  els.alertList.innerHTML = systemData.alerts.map(alert => `
    <div class="alert-card">
      <div class="alert-icon ${alert.type}">${getAlertIcon(alert.type)}</div>
      <div class="alert-content">
        <div class="alert-title">${alert.title}</div>
        <div class="alert-message">${alert.message}</div>
        <div class="alert-time">${alert.time}</div>
      </div>
    </div>
  `).join('');
}

// Get alert icon
function getAlertIcon(type) {
  const icons = {
    error: '⚠️',
    warning: '⚡',
    info: 'ℹ️'
  };
  return icons[type] || '•';
}

// Control agent
async function controlAgent(agentId, action) {
  showToast(`${action === 'start' ? 'Starting' : 'Stopping'} ${agentId}...`);
  
  try {
    const response = await fetch(`/api/agent/${encodeURIComponent(agentId)}/control`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action })
    });
    
    const result = await response.json();
    if (result.success) {
      showToast(`${agentId} ${action}ed successfully`);
      setTimeout(fetchData, 1000); // Refresh after delay
    } else {
      showToast(`Failed: ${result.message}`);
    }
  } catch (error) {
    showToast('Network error');
  }
}

// Show toast notification
function showToast(message) {
  // Remove existing toast
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.remove(), 3000);
}

// Quick actions
document.querySelectorAll('.action-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const action = btn.dataset.action;
    showToast(`Running ${action}...`);
    
    // Simulate action
    setTimeout(() => {
      showToast(`${action} completed`);
      fetchData();
    }, 1500);
  });
});

// Refresh button
els.refreshBtn.addEventListener('click', fetchData);

// Add agent button
els.addAgentBtn.addEventListener('click', () => {
  showToast('Agent creation coming soon!');
});

// Navigation
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    
    const view = item.dataset.view;
    showToast(`${view} view - coming soon!`);
  });
});

// Haptic feedback helper
function hapticFeedback(style = 'medium') {
  if (tg.HapticFeedback) {
    tg.HapticFeedback.impactOccurred(style);
  }
}

// Initialize
fetchData();

// Auto-refresh every 30 seconds
refreshInterval = setInterval(fetchData, 30000);

// Cleanup on page hide
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    clearInterval(refreshInterval);
  } else {
    fetchData();
    refreshInterval = setInterval(fetchData, 30000);
  }
});

// Close button (if in modal)
if (tg.onCloseButtonClicked) {
  tg.onCloseButtonClicked(() => tg.close());
}
