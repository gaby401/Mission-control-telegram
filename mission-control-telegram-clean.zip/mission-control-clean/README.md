# Mission Control Telegram Mini App

A Telegram Mini App for controlling and monitoring your Mission Control dashboard from anywhere.

## Features

- 📊 Real-time system status
- 🤖 Agent control (start/stop)
- 💰 Revenue tracking
- ⚠️ Alert monitoring
- ⚡ Quick actions
- 🌙 Dark glassmorphism UI
- 📱 Mobile-optimized

## Quick Start

### 1. Create a Telegram Bot

1. Message `@BotFather` on Telegram
2. Send `/newbot` and follow instructions
3. Save the bot token

### 2. Configure

```bash
cp .env.example .env
# Edit .env and add your bot token
```

### 3. Install & Run

```bash
npm install
npm start
```

The server starts on `http://localhost:3000`

### 4. Deploy

For production, deploy to a server with HTTPS (required by Telegram):

```bash
# Build and run with Docker
docker build -t mission-control-telegram .
docker run -p 3000:3000 --env-file .env mission-control-telegram
```

Or use any Node.js hosting (Railway, Render, Heroku, etc.)

### 5. Set Web App URL

1. Message `@BotFather`
2. `/mybots` → select your bot → `Bot Settings` → `Menu Button`
3. Set URL to your deployed web app (e.g., `https://yourdomain.com`)
4. Or use `/setmenubutton` command

## API Endpoints

- `GET /api/status` - Get system status
- `POST /api/agent/:id/control` - Control an agent (body: `{action: "start"|"stop"}`)

## Integration with Existing Backend

To connect to your real Mission Control backend:

1. Update `index.js` to proxy requests to your API
2. Modify `web/app.js` fetch URLs
3. Add authentication if needed

## Project Structure

```
mission-control-telegram/
├── index.js          # Bot + Express server
├── web/
│   ├── index.html   # Mini app UI
│   ├── styles.css   # Glassmorphism styles
│   └── app.js       # Frontend logic
├── package.json
└── README.md
```

## Customization

- Colors: Edit CSS variables in `web/styles.css`
- Icons: Update emoji or icon fonts
- Layout: Modify HTML structure in `web/index.html`
- Data source: Change API endpoints in `web/app.js`

## Requirements

- Node.js 18+
- Telegram bot token
- HTTPS domain (for production)

## License

MIT
